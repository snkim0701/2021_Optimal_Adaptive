
%% MPC-MISO: mpc_gs 3-51
 
clear all; clc
plantTF = tf({1,1,1},{[1 .5 1],[1 1],[.7 .5 1]});

% discretization
plantCSS = ss(plantTF) % convert plant from transfer function to continuous-time state space

% pUD = tf([1 2],[1 0 10]);
% kim=ss(pUD);
% csys = canon(kim,'companion')
%
Ts = 0.2;                    % specify a sample time of 0.2 seconds
plantDSS = c2d(plantCSS,Ts) % with ZOH

%

% specify inputs
plantDSS = setmpcsignals(plantDSS,'MV',1,'MD',2,'UD',3); % specify signal types

%MV: manipulated variables 
%MD : measured disturbance
%UD : unmeasured disturbance

plantDSS = setmpcsignals(plantDSS,'MV',1,'MD',2,'UD',3); % specify signal types

% design MPC
mpcobj = mpc(plantDSS,Ts,10,3)

%%
mpcobj.MV = struct('Min',0,'Max',1,'RateMin',-10,'RateMax',10);
mpcobj.Model.Disturbance = tf(sqrt(1000),[1 0]);

mpcobj
getindist(mpcobj)

% kim= tf(sqrt(1000),[1,0]);
% pC = ss(kim)
% Ts = 0.2;
% pD = c2d(pC, Ts)


%% 

DC = cloffset(mpcobj);
fprintf('DC gain from output disturbance to output = %5.8f (=%g) \n',DC,DC);

%%
Tstop = 30; % simulation time
Nf = round(Tstop/Ts); % number of simulation steps
r = ones(Nf,1); % output reference signal
v = [zeros(Nf/3,1);ones(2*Nf/3,1)]; % measured input disturbance signal
sim(mpcobj,Nf,r,v) % simulate plant and controller in closed loop

%% options for unmeasured signals

SimOptions = mpcsimopt; % create object %

%Create a disturbance signal and specify it in the simulation options object
d = [zeros(2*Nf/3,1);-0.5*ones(Nf/3,1)]; % define a step disturbance signal
SimOptions.UnmeasuredDisturbance = d; % specify unmeasured input disturbance signal
SimOptions.OutputNoise=.001*(rand(Nf,1)-.5); % specify output measurement noise
SimOptions.InputNoise=.05*(rand(Nf,1)-.5); % specify noise on manipulated variables

[y,t,u,xp] = sim(mpcobj,Nf,r,v,SimOptions); % simulate closed loop

figure % create new figure
subplot(2,1,1) % create upper subplot
plot(0:Nf-1,y,0:Nf-1,r) % plot plant output and reference
title('Output') % add title so upper subplot
ylabel('MO1') % add a label to the upper y axis
grid % add a grid to upper subplot
subplot(2,1,2) % create lower subplot
plot(0:Nf-1,u) % plot manipulated variable
title('Input'); % add title so lower subplot
xlabel('Simulation steps') % add a label to the lower x axis
ylabel('MV1') % add a label to the lower y axis
grid % add a grid to lower subplot

%% 

[L,M,A1,Cm1] = getEstimator(mpcobj); % retrieve observer matrices
e = eig(A1-A1*M*Cm1);


% Design a new state estimator by pole-placement.
poles = [.8 .75 .7 .85 .6 .81];         % specify desired positions for the new poles
L = place(A1',Cm1',poles)';          % calculate Kalman gain for time update
M = A1\L;                              % calculate Kalman gain for measurement update

setEstimator(mpcobj,L,M); % set the new estimation gains
% re-run the closed loop simulation
[y,t,u,xp,xc] = sim(mpcobj,Nf,r,v,SimOptions);

figure; % create figure
subplot(2,1,1) % create upper subplot axis
plot(t,y) % plot y versus time
title('Plant output'); % add title to upper plot
ylabel('y') % add a label to the upper y axis
grid % add grid to upper plot
subplot(2,1,2) % create lower subplot axis
plot(t,xc.Plant) % plot xc.Plant versus time
title('Estimated plant states'); % add title to lower plot
xlabel('Time (sec)') % add a label to the lower x axis
ylabel('xc') % add a label to the lower y axis
grid %
%%


clear all; clc
mpcverbosity off;          % turn off mpc messaging
% plant=tf(1,[1 1],0.2);     % create plant (0.2 seconds sampling time)
dcgain(mpcobj)

%%

