
clear all; clc

s = tf('s');
G = 1/(s^2 + s + 10)
figure
bode(G); grid on

%
A =[0 1;-10 -1];
B=[0 ; 1];
C =[ 1 0];
D = 0;
[num, den] = ss2tf(A,B,C,D);
Gg =tf(num,den);

%
[A1 ,B1,C1,D1] = tf2ss(G.num{1}, G.den{1});

figure
impulse(G)
figure
step(G)

%%
S = 1/(1+G);
figure
bode(S) ; grid on ; hold on ;
T = G/(1+G)
bode(T)