
%% matlab_lqr
% For Observer_Kim.slx

A=[0 1; 1 1];
B =[0 ;1];

C =[1 0; 0 1];
D = 0;

Q = [10 0; 0 1];        %  
R =1;                     %  

% check controllability
[Kr, p,e] = lqr(A,B,Q,R);
poles=eig(A-B*Kr);
sys =ss(A,B,C,D);

%
[num,den] =ss2tf(A,B,[1 0],0)


%
Kc =-1/([1 0]*(inv(A-B*Kr)*B));  % for unity gain
%output feedback sysO

AO = A;
BO =B;
CO =[1 0];
DO = D;
sysO =ss(A,B,CO,D);

% output feedback tp place the poles
% check observability 
Kl = (place(AO', CO', [-2+j*2  -2-j*2]))';

% model uncertainty 
% AO = A + [0 1; -0.1 -0.2];
% BO =B;
% CO =[1 0];
% DO = D;
% sysO =ss(A,B,CO,D);

% output feedback tp place the poles
% check observability 
Kl = (place(AO', CO', [-2+j*2  -2-j*2]))';

% Observer
A_ob  = [AO-Kl*CO];
B_ob =[BO Kl];
C_ob = eye(2);
D_ob = DO;

sys_ob=ss(A_ob,B_ob,C_ob, D_ob);

Kc = -CO*inv(A-B*Kr)*B

%% reference tracking
%%  Bias method
clear all; clc

A=[0 1; 0 0];
B =[0 ;1];
C =[1 0; 0 1];
D = 0;

Q = [10 0; 0 1];        %  
R =1;                     %  

% check controllability
[Kr, p,e] = lqr(A,B,Q,R);
poles=eig(A-B*Kr);
sys =ss(A,B,C,D);

%
[num,den] =ss2tf(A,B,[1 0],0)


%
Kc =-1/([1 0]*(inv(A-B*Kr)*B));  % for unity gain
%output feedback sysO

AO = A;
BO =B;
CO =[1 0];
DO = D;
sysO =ss(A,B,CO,D);

% output feedback tp place the poles
% check observability 
Kl = (place(AO', CO', [-2+j*2  -2-j*2]))';

% model uncertainty 
% AO = A + [0 1; -0.1 -0.2];
% BO =B;
% CO =[1 0];
% DO = D;
% sysO =ss(A,B,CO,D);

% output feedback tp place the poles
% check observability 
Kl = (place(AO', CO', [-2+j*2  -2-j*2]))';

% Observer
A_ob  = [AO-Kl*CO];
B_ob =[BO Kl];
C_ob = eye(2);
D_ob = DO;

sys_ob=ss(A_ob,B_ob,C_ob, D_ob);

% Kc = -CO*inv(A-B*Kr)*B

%% Feedforward -- need pre compensator gain

clear all; clc

A=[0 1; 0 0];
B =[0 ;1];
C =[1 0; 0 1];
D = 0;

Q = [10 0; 0 1];        %  
R =1;                     %  

% check controllability
[Kr, p,e] = lqr(A,B,Q,R);
poles=eig(A-B*Kr);
sys =ss(A,B,C,D);

%
[num,den] =ss2tf(A,B,[1 0],0)

Kc =-1/([1 0]*(inv(A-B*Kr)*B));  % for unity gain
%output feedback sysO

AO = A;
BO =B;
CO =[1 0];
DO = D;
sysO =ss(A,B,CO,D);

% output feedback tp place the poles
% check observability 
Kl = (place(AO', CO', [-2+j*2  -2-j*2]))';

% model uncertainty 
% AO = A + [0 1; -0.1 -0.2];
% BO =B;
% CO =[1 0];
% DO = D;
% sysO =ss(A,B,CO,D);

% output feedback tp place the poles
% check observability 
Kl = (place(AO', CO', [-2+j*2  -2-j*2]))';

% Observer
A_ob  = [AO-Kl*CO];
B_ob =[BO Kl];
C_ob = eye(2);
D_ob = DO;

sys_ob=ss(A_ob,B_ob,C_ob, D_ob);

% Kc = -CO*inv(A-B*Kr)*B


%% Integral
A=[0 1;-10 -1];
B = [ 0;1];
AI  = [A [0 0]'; -1 0 0];
BI  = [ 0 1 0]';
CI = eye(3);
DI = 0;

QI =[0 0 0; 0 0 0; 0 0 1];
RI = 0.0001;

[k, p,e] = lqr(AI,BI,QI,RI);
k
sys = ss(A,B,eye(2),DI);

%% known disturbance rejection with state feedback
clear all;clc
A=[-1 1;0 -0.1];
B =[0; 0.1];
BO =[1 0; 0 0.1];
C =[1 0];
CO =eye(2);
D =0;
G =[1 0]';;

Q = [1 0; 0 0];        %  
R =0.001;                     %  

% check controllability
[Kr, p,e] = lqr(A,B,Q,R);
Kr
%
Kc =-inv(C*inv(A-B*Kr)*B)*C*inv(A-B*Kr)*G

% state feedback with additional disturbance
sys =ss(A,BO,CO,D);



