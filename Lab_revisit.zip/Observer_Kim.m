
%% matlab_lqr
% dx = Ax + Bu 
% y = Cx 
% lqr(Q,R)
% clear all; clc

A=[0 1; 1 1];
B =[0 ;1];
C =[1 0; 0 1];
D = 0;

Q = [10 0; 0 1];        %  
R =1;                     %  

% check controllability
[Kr, p,e] = lqr(A,B,Q,R);
poles=eig(A-B*Kr);
sys =ss(A,B,C,D);

%
[num,den] =ss2tf(A,B,[1 0],0)


%
Kc =-1/([1 0]*(inv(A-B*Kr)*B));  % for unity gain
%output feedback sysO

AO = A;
BO =B;
CO =[1 0];
DO = D;
sysO =ss(A,B,CO,D);

% output feedback tp place the poles
% check observability 
Kl = (place(AO', CO', [-2+j*2  -2-j*2]))';

% model uncertainty 
% AO = A + [0 1; -0.1 -0.2];
% BO =B;
% CO =[1 0];
% DO = D;
% sysO =ss(A,B,CO,D);

% output feedback tp place the poles
% check observability 
Kl = (place(AO', CO', [-2+j*2  -2-j*2]))';

% Observer
A_ob  = [AO-Kl*CO];
B_ob =[BO Kl];
C_ob = eye(2);
D_ob = DO;

sys_ob=ss(A_ob,B_ob,C_ob, D_ob);

% Tp = (-inv(A-B*Kr)*Kl*CO -eye(2))

%%




