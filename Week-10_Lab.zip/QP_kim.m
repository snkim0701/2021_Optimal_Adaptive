
%%

% clear all; clc
% x = 0:0.1:10;
% y = 0:0.1:10;
[X,Y] = meshgrid(0:0.1:10,0:0.1:10)
cost  = 0.4*X.^2 -5*X+Y.^2- 6*Y+50;

figure(1)
contour(X,Y,cost,'Linewidth',2);
xlabel('x')
ylabel('y')
zlabel('cost')

hold on
plot([0;8],[2;10],'k','Linewidth',2)
plot([0;10],[8;5],'k','Linewidth',2)

H = 2*[0.4 0; 0 1];
f =[-5 ; -6];
A =[1 -1; -0.3 -1];
b =[-2;-8];
LB=[0;0];
UB =[10;10]
[X,J] = quadprog(H,f,A,b,[ ], [ ],LB,UB);
plot(X(1), X(2), 'r.','Markersize',30)